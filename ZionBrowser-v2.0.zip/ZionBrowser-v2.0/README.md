# ZionBrowser v2.0 — AI Agent Browser Toolkit

**Pure Python. ZERO Dependencies. ~5MB RAM.**

A complete CLI browser toolkit for AI agents on resource-constrained machines.
While headless Chrome consumes 500MB+, ZionBrowser does everything in ~5MB.

## Quick Start

```bash
# Make scripts executable
chmod +x install.sh
./install.sh

# Or run directly
python3 zion_browser.py --help
python3 lion.py --help
python3 pirate.py scan
```

## 6 Modules

| Module | File | Lines | Purpose |
|--------|------|-------|---------|
| **ZionBrowser** | zion_browser.py | 1,847 | CLI HTTP browser, cookies, search, API server |
| **ZionCDP** | zion_cdp.py | 827 | Chrome DevTools Protocol (low RAM) |
| **ZionAgent** | zion_agent.py | 669 | AI agent framework for multi-step web tasks |
| **LION** | lion.py | 826 | Learning navigation brain, auto-adapts |
| **LION-1** | lion_one.py | 1,004 | Token hunter + prompt injection shield |
| **PIRATE** | pirate.py | 1,028 | 8-layer security defender |

**Total: 6,232 lines | 388KB | Pure Python stdlib**

## Key Features

- **HTTP browser** with cookie persistence (678+ cookies)
- **DuckDuckGo search** from the terminal
- **Chrome DevTools Protocol** for JS-heavy sites (64MB V8 heap limit)
- **Auto-fallback**: Chrome -> HTTP when Chrome crashes or RAM is low
- **Learning brain**: LION remembers which sites need which approach
- **Token hunter**: Finds cookies, API keys, auth tokens across browsers
- **Prompt injection shield**: Detects malicious content targeting AI agents
- **File integrity**: SHA256 monitoring of critical files
- **Rootkit detection**: 7-point security check
- **Process/network scanning**: Real-time machine monitoring

## Requirements

- Python 3.6+ (stdlib only)
- No pip install. No virtualenv. No Docker.
- Linux, macOS, Windows, Raspberry Pi, any VPS

## Usage Examples

```bash
# Browse a URL
python3 zion_browser.py get https://example.com

# Search the web
python3 zion_browser.py search "Python MCP servers"

# Chrome DevTools (for JS sites)
python3 zion_cdp.py get https://app.example.com

# Security scan
python3 pirate.py scan

# Learn about a site
python3 lion.py navigate https://github.com

# Hunt for tokens
python3 lion_one.py hunt
```

## Why ZERO Dependencies?

On a fresh VPS or locked-down environment, you copy the files and it runs.
No version conflicts. No compiled C extensions that fail on ARM.
No 200MB of Selenium/Playwright driver binaries. It just works.

## Support

- Email: standardbitcoin.io@gmail.com
- GitHub: https://github.com/ElromEvedElElyon/zion-browser

## License

Commercial License - Padrao Bitcoin LTDA
CNPJ: 51.148.891/0001-69
Copyright 2026. All rights reserved.
